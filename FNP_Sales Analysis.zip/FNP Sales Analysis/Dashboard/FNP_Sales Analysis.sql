SELECT * FROM fnp.products;
SELECT Order_Date FROM orders;
set sql_safe_updates =0;
 # Order_Date and Delivery_Date are not in Date format so converted to Date Format...
ALTER TABLE orders ADD COLUMN New_Order_Date DATE;
UPDATE orders
SET New_Order_Date = STR_TO_DATE(Order_Date, '%d-%m-%Y');

SELECT New_Order_Date FROM orders;

ALTER TABLE orders ADD COLUMN New_Delivery_Date DATE;

UPDATE orders
SET New_Delivery_Date = STR_TO_DATE(Delivery_Date, '%d-%m-%Y');

SELECT New_Delivery_Date FROM orders;

# Total Order 
SELECT SUM(o.Quantity * p.`Price (INR)`) AS Total_Revenue
FROM orders o 
JOIN products p ON O.Product_ID = P.Product_ID;

# Total Order 
SELECT COUNT(Order_ID) AS Total_Order
FROM orders;

# Customer's Spending 
SELECT AVG(o.Quantity * p.`Price (INR)`) AS `Customer's_Spending`
FROM orders o 
JOIN products p ON O.Product_ID = P.Product_ID;

#  Difference between Delivery and Order Date 
SELECT 
ROUND(AVG(DATEDIFF(New_Delivery_Date, New_Order_Date)),2) AS Order_Delivery_Time
FROM orders;

# 1..Month Wise Revenue

SELECT 
    MONTHNAME(o.New_Order_Date) AS Month, 
    SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM orders o 
JOIN products p ON o.Product_ID = p.Product_ID
GROUP BY MONTH(o.New_Order_Date), MONTHNAME(o.New_Order_Date)
ORDER BY MONTH(o.New_Order_Date) ASC;

# 2..Occasion Wise Revenue

SELECT p.Occasion,
SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM products p 
JOIN orders o ON P.Product_ID = o.Product_ID
GROUP BY p.Occasion
ORDER BY Revenue DESC;

# OR

SELECT p.Occasion,
    CONCAT((ROUND(SUM(o.Quantity * p.`Price (INR)`) / 1000, 0)),'K') AS Revenue
FROM products p 
JOIN orders o ON P.Product_ID = o.Product_ID
GROUP BY p.Occasion
ORDER BY Revenue DESC;

#3..Category Wise Revenue

SELECT p.Category,
SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM products p 
JOIN orders o ON P.Product_ID = o.Product_ID
GROUP BY p.Category
ORDER BY Revenue DESC;

# 4..Day Wise Sales

SELECT DAYNAME(o.New_Order_Date) AS Day,
SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM orders o 
JOIN products p ON o.Product_ID = p.Product_ID
GROUP BY Day
ORDER BY Revenue DESC;

# 5..Hour(Order_Time) wise Revenue and Total Order

SELECT HOUR(o.Order_Time) AS Order_Time, 
COUNT(o.Order_ID) AS Total_Order,
SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM orders o 
JOIN products p ON o.Product_ID = p.Product_ID
GROUP BY HOUR(o.Order_Time)
ORDER BY Order_Time ASC;

# 6..Top 10 City Wise Revenue

SELECT c.City,
SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM customers c 
JOIN orders o ON c.Customer_ID = o.Customer_ID
JOIN Products p ON o.Product_ID = p.Product_ID
GROUP BY c.City
ORDER BY  Revenue DESC
LIMIT 10;

# 7.. Top 5 Product wise Revenue

SELECT p.Product_Name AS Product,
SUM(o.Quantity * p.`Price (INR)`) AS Revenue
FROM products p 
JOIN orders o ON p.Product_ID = o.Product_ID
GROUP BY p.Product_Name
ORDER BY Revenue DESC
LIMIT 5;












